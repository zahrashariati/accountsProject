const form = document.querySelector("form"),
fileInput =form.querySelector(".file-input"),
progressArea = document.querySelector(".progress-area"),
uploadedArea = document.querySelector("uploaded-area");

form.addEventListener("click" , ()=>{
    fileInput.click();
});

fileInput.onchange = ({target}) => {
    let file = target.files[0]; //if selected multiple files , get the first one in row
    if(file){
        let fileName = file.name; //getting file name
        uploadFile(fileName);
    }
}

function uploadFile(name){
    let xhr = new XMLHttpRequest(); //create new XML obj ajax
    xhr.open("POST" , "php/upload.php"); //sending post request
    xhr.upload.addEventListener("progress" , ({loaded , total})=>{
        let fileLoaded = Math.floor((loaded , total) * 100); //getting percentage of loaded file size
        let fileTotal = Math.floor(total / 1000); //getting file size
        let fileSize;
        (fileTotal < 1024) ? fileSize = fileTotal + " KB" : fileSize = (loaded / (1024 * 1024)).toFixed(2) + " MB" 
                // console.log(fileLoaded ,fileTotal)
        let progressHTML = `<li class="row">
                                <i class="fa fa-file"></i>
                                <div class="content">
                                    <div class="details">
                                        <span class="name"> ${name} . در حال بارگذاری</span>
                                        <span class="percent">${fileLoaded}</span>
                                    </div>
                                    <div class="progress-bar">
                                        <div class="progress"> style = "width : ${fileLoaded}%"</div>
                                    </div>
                                </div>
                            </li>`;
        
        uploadedArea.classList.add("onprogress");
        progressArea.innerHTML = progressHTML;

        if(loaded == total){
            progressArea.innerHTML = "";
            let uploadedHTML =`<li class="row">
                                <div class="content">
                                    <i class="fa fa-file"></i>
                                    <div class="details">
                                        <span class="name">${name} . بارگذاری شد</span>
                                        <span class="size">${fileTotal}</span>
                                    </div>
                                </div>
                                <i class="fa fa-check"></i>
                            </li>`;

            uploadedArea.classList.remove("onprogress");
            uploadedArea.insertAdjacentHTML("afterbegin" , uploadedHTML);
        } 
    });
    // xhr.upload.addEventListener("progress" , e =>{
    //     console.log(e);
    // });

    let formData = new FormData(form);
    xhr.send(formData);
}
